set encoding iso_8859_1
set xrange [1:120]
set yrange [0.83:1.2]
set autoscale xfix
set ter png enh interlace size 2400,840 font 'Nimbus,40'
set xlabel 'Position'
set ylabel 'Reliability           ' 
set ytics nomirror 0.6,0.1,1
set out '/static/tmp/tmp_Ebgyx9/rst_gHUXQd/seq_0///Topcons/topcons.large.png'
set tmargin 1.3
set lmargin 11.5
set rmargin 6.5
set label 'TOPCONS' font 'Nimbus,42' at screen 0.022,0.775
set object 1 rect from 0.5,1.08 to 11.5,1.0865 fc rgb "red" fs noborder
set object 2 rect from 54.5,1.08 to 67.5,1.0865 fc rgb "red" fs noborder
set object 3 rect from 115.5,1.08 to 120.5,1.0865 fc rgb "red" fs noborder
set object 4 rect from 32.5,1.1085 to 33.5,1.115 fc rgb "blue" fs noborder
set object 5 rect from 88.5,1.1085 to 94.5,1.115 fc rgb "blue" fs noborder
set object 6 rect from 11.5,1.08 to 32.5,1.115 fc rgb "grey" fs noborder
set object 7 rect from 33.5,1.08 to 54.5,1.115 fc rgb "white"
set object 8 rect from 67.5,1.08 to 88.5,1.115 fc rgb "grey" fs noborder
set object 9 rect from 94.5,1.08 to 115.5,1.115 fc rgb "white"
set object 10 rect from 11.5,1.08 to 32.5,1.115 fc rgb "grey" fs noborder
set object 11 rect from 33.5,1.08 to 54.5,1.115 fc rgb "white"
set object 12 rect from 67.5,1.08 to 88.5,1.115 fc rgb "grey" fs noborder
set object 13 rect from 94.5,1.08 to 115.5,1.115 fc rgb "white"
plot '/static/tmp/tmp_Ebgyx9/rst_gHUXQd/seq_0///Topcons/reliability.final' w l t '' lc rgb "black" lw 4
exit
