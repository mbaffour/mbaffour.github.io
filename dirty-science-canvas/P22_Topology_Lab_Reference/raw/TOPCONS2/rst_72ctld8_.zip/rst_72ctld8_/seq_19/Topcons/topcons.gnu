set encoding iso_8859_1
set xrange [1:486]
set yrange [0.83:1.2]
set autoscale xfix
set ter png enh interlace size 2400,840 font 'Nimbus,40'
set xlabel 'Position'
set ylabel 'Reliability           ' 
set ytics nomirror 0.6,0.1,1
set out '/static/tmp/tmp_lgKEPk/rst_eI5I8V/seq_0///Topcons/topcons.large.png'
set tmargin 1.3
set lmargin 11.5
set rmargin 6.5
set label 'TOPCONS' font 'Nimbus,42' at screen 0.022,0.775
set object 1 rect from 0.5,1.08 to 9.5,1.0865 fc rgb "red" fs noborder
set object 2 rect from 91.5,1.08 to 95.5,1.0865 fc rgb "red" fs noborder
set object 3 rect from 142.5,1.08 to 143.5,1.0865 fc rgb "red" fs noborder
set object 4 rect from 186.5,1.08 to 193.5,1.0865 fc rgb "red" fs noborder
set object 5 rect from 279.5,1.08 to 291.5,1.0865 fc rgb "red" fs noborder
set object 6 rect from 340.5,1.08 to 347.5,1.0865 fc rgb "red" fs noborder
set object 7 rect from 30.5,1.1085 to 70.5,1.115 fc rgb "blue" fs noborder
set object 8 rect from 116.5,1.1085 to 121.5,1.115 fc rgb "blue" fs noborder
set object 9 rect from 164.5,1.1085 to 165.5,1.115 fc rgb "blue" fs noborder
set object 10 rect from 214.5,1.1085 to 258.5,1.115 fc rgb "blue" fs noborder
set object 11 rect from 312.5,1.1085 to 319.5,1.115 fc rgb "blue" fs noborder
set object 12 rect from 368.5,1.1085 to 486.5,1.115 fc rgb "blue" fs noborder
set object 13 rect from 9.5,1.08 to 30.5,1.115 fc rgb "grey" fs noborder
set object 14 rect from 70.5,1.08 to 91.5,1.115 fc rgb "white"
set object 15 rect from 95.5,1.08 to 116.5,1.115 fc rgb "grey" fs noborder
set object 16 rect from 121.5,1.08 to 142.5,1.115 fc rgb "white"
set object 17 rect from 143.5,1.08 to 164.5,1.115 fc rgb "grey" fs noborder
set object 18 rect from 165.5,1.08 to 186.5,1.115 fc rgb "white"
set object 19 rect from 193.5,1.08 to 214.5,1.115 fc rgb "grey" fs noborder
set object 20 rect from 258.5,1.08 to 279.5,1.115 fc rgb "white"
set object 21 rect from 291.5,1.08 to 312.5,1.115 fc rgb "grey" fs noborder
set object 22 rect from 319.5,1.08 to 340.5,1.115 fc rgb "white"
set object 23 rect from 347.5,1.08 to 368.5,1.115 fc rgb "grey" fs noborder
set object 24 rect from 9.5,1.08 to 30.5,1.115 fc rgb "grey" fs noborder
set object 25 rect from 70.5,1.08 to 91.5,1.115 fc rgb "white"
set object 26 rect from 95.5,1.08 to 116.5,1.115 fc rgb "grey" fs noborder
set object 27 rect from 121.5,1.08 to 142.5,1.115 fc rgb "white"
set object 28 rect from 143.5,1.08 to 164.5,1.115 fc rgb "grey" fs noborder
set object 29 rect from 165.5,1.08 to 186.5,1.115 fc rgb "white"
set object 30 rect from 193.5,1.08 to 214.5,1.115 fc rgb "grey" fs noborder
set object 31 rect from 258.5,1.08 to 279.5,1.115 fc rgb "white"
set object 32 rect from 291.5,1.08 to 312.5,1.115 fc rgb "grey" fs noborder
set object 33 rect from 319.5,1.08 to 340.5,1.115 fc rgb "white"
set object 34 rect from 347.5,1.08 to 368.5,1.115 fc rgb "grey" fs noborder
plot '/static/tmp/tmp_lgKEPk/rst_eI5I8V/seq_0///Topcons/reliability.final' w l t '' lc rgb "black" lw 4
exit
