set style line 11 lt 1 lw 1 lc rgb "blue"
set encoding iso_8859_1
set yrange [0:50]
set xrange [1:486]
set y2range [-2:36.6]
set autoscale xfix
set ter png enh interlace size 2400,1680 font 'Nimbus,40'
set y2label '{/Symbol D}G (kcal/mol)                                             ' tc lt 3
set ytics scale 1,0.0 nomirror ("PDB-homology" 26.9 0, "SPOCTOPUS" 32.9 0, "SCAMPI" 35.9 0, "PolyPhobius" 38.9 0, "Philius" 41.9 0, "OCTOPUS" 44.9 0, "TOPCONS" 47.9 0)
set y2tics nomirror -3,2,15
set out '/static/tmp/tmp_lgKEPk/rst_eI5I8V/seq_0///Topcons/total_image.large.png'
set lmargin 13.5
set rmargin 6.5
set tmargin 1.3
set object 1 rect from screen 0.19,0.986 to screen 0.21,0.992 fc rgb "red" fs noborder
set label 'Inside' font 'Nimbus,30' at screen 0.215,0.982
set object 2 rect from screen 0.28,0.986 to screen 0.30,0.992 fc rgb "blue" fs noborder
set label 'Outside' font 'Nimbus,30' at screen 0.305,0.982
set object 3 rect from screen 0.38,0.978 to screen 0.40,1 fc rgb "grey" fs noborder
set label 'TM-helix (IN->OUT)' font 'Nimbus,30' at screen 0.405,0.982
set object 4 rect from screen 0.57,0.978 to screen 0.59,1 fc rgb "white"
set label 'TM-helix (OUT->IN)' font 'Nimbus,30' at screen 0.595,0.982
set object 5 rect from screen 0.76,0.978 to screen 0.78,1 fc rgb "black"
set label 'Signal peptide' font 'Nimbus,30' at screen 0.785,0.982
set ytic scale 0
set label "***No homologous TM proteins detected***" at 10, 26.4 font "Nimbus,35"
set object 6 rect from 0.5,32.4 to 9.5,32.6 fc rgb "red" fs noborder
set object 7 rect from 91.5,32.4 to 94.5,32.6 fc rgb "red" fs noborder
set object 8 rect from 142.5,32.4 to 149.5,32.6 fc rgb "red" fs noborder
set object 9 rect from 180.5,32.4 to 193.5,32.6 fc rgb "red" fs noborder
set object 10 rect from 279.5,32.4 to 291.5,32.6 fc rgb "red" fs noborder
set object 11 rect from 340.5,32.4 to 347.5,32.6 fc rgb "red" fs noborder
set object 12 rect from 30.5,33.2 to 70.5,33.4 fc rgb "blue" fs noborder
set object 13 rect from 115.5,33.2 to 121.5,33.4 fc rgb "blue" fs noborder
set object 14 rect from 164.5,33.2 to 165.5,33.4 fc rgb "blue" fs noborder
set object 15 rect from 214.5,33.2 to 258.5,33.4 fc rgb "blue" fs noborder
set object 16 rect from 312.5,33.2 to 319.5,33.4 fc rgb "blue" fs noborder
set object 17 rect from 368.5,33.2 to 486.5,33.4 fc rgb "blue" fs noborder
set object 18 rect from 9.5,32.4 to 30.5,33.4 fc rgb "grey" fs noborder
set object 19 rect from 70.5,32.4 to 91.5,33.4 fc rgb "white"
set object 20 rect from 94.5,32.4 to 115.5,33.4 fc rgb "grey" fs noborder
set object 21 rect from 121.5,32.4 to 142.5,33.4 fc rgb "white"
set object 22 rect from 149.5,32.4 to 164.5,33.4 fc rgb "grey" fs noborder
set object 23 rect from 165.5,32.4 to 180.5,33.4 fc rgb "white"
set object 24 rect from 193.5,32.4 to 214.5,33.4 fc rgb "grey" fs noborder
set object 25 rect from 258.5,32.4 to 279.5,33.4 fc rgb "white"
set object 26 rect from 291.5,32.4 to 312.5,33.4 fc rgb "grey" fs noborder
set object 27 rect from 319.5,32.4 to 340.5,33.4 fc rgb "white"
set object 28 rect from 347.5,32.4 to 368.5,33.4 fc rgb "grey" fs noborder
set object 29 rect from 9.5,32.4 to 30.5,33.4 fc rgb "grey" fs noborder
set object 30 rect from 70.5,32.4 to 91.5,33.4 fc rgb "white"
set object 31 rect from 94.5,32.4 to 115.5,33.4 fc rgb "grey" fs noborder
set object 32 rect from 121.5,32.4 to 142.5,33.4 fc rgb "white"
set object 33 rect from 149.5,32.4 to 164.5,33.4 fc rgb "grey" fs noborder
set object 34 rect from 165.5,32.4 to 180.5,33.4 fc rgb "white"
set object 35 rect from 193.5,32.4 to 214.5,33.4 fc rgb "grey" fs noborder
set object 36 rect from 258.5,32.4 to 279.5,33.4 fc rgb "white"
set object 37 rect from 291.5,32.4 to 312.5,33.4 fc rgb "grey" fs noborder
set object 38 rect from 319.5,32.4 to 340.5,33.4 fc rgb "white"
set object 39 rect from 347.5,32.4 to 368.5,33.4 fc rgb "grey" fs noborder
set object 40 rect from 0.5,35.4 to 13.5,35.6 fc rgb "red" fs noborder
set object 41 rect from 90.5,35.4 to 98.5,35.6 fc rgb "red" fs noborder
set object 42 rect from 141.5,35.4 to 143.5,35.6 fc rgb "red" fs noborder
set object 43 rect from 186.5,35.4 to 194.5,35.6 fc rgb "red" fs noborder
set object 44 rect from 279.5,35.4 to 294.5,35.6 fc rgb "red" fs noborder
set object 45 rect from 342.5,35.4 to 347.5,35.6 fc rgb "red" fs noborder
set object 46 rect from 34.5,36.2 to 69.5,36.4 fc rgb "blue" fs noborder
set object 47 rect from 119.5,36.2 to 120.5,36.4 fc rgb "blue" fs noborder
set object 48 rect from 164.5,36.2 to 165.5,36.4 fc rgb "blue" fs noborder
set object 49 rect from 215.5,36.2 to 258.5,36.4 fc rgb "blue" fs noborder
set object 50 rect from 315.5,36.2 to 321.5,36.4 fc rgb "blue" fs noborder
set object 51 rect from 368.5,36.2 to 486.5,36.4 fc rgb "blue" fs noborder
set object 52 rect from 13.5,35.4 to 34.5,36.4 fc rgb "grey" fs noborder
set object 53 rect from 69.5,35.4 to 90.5,36.4 fc rgb "white"
set object 54 rect from 98.5,35.4 to 119.5,36.4 fc rgb "grey" fs noborder
set object 55 rect from 120.5,35.4 to 141.5,36.4 fc rgb "white"
set object 56 rect from 143.5,35.4 to 164.5,36.4 fc rgb "grey" fs noborder
set object 57 rect from 165.5,35.4 to 186.5,36.4 fc rgb "white"
set object 58 rect from 194.5,35.4 to 215.5,36.4 fc rgb "grey" fs noborder
set object 59 rect from 258.5,35.4 to 279.5,36.4 fc rgb "white"
set object 60 rect from 294.5,35.4 to 315.5,36.4 fc rgb "grey" fs noborder
set object 61 rect from 321.5,35.4 to 342.5,36.4 fc rgb "white"
set object 62 rect from 347.5,35.4 to 368.5,36.4 fc rgb "grey" fs noborder
set object 63 rect from 13.5,35.4 to 34.5,36.4 fc rgb "grey" fs noborder
set object 64 rect from 69.5,35.4 to 90.5,36.4 fc rgb "white"
set object 65 rect from 98.5,35.4 to 119.5,36.4 fc rgb "grey" fs noborder
set object 66 rect from 120.5,35.4 to 141.5,36.4 fc rgb "white"
set object 67 rect from 143.5,35.4 to 164.5,36.4 fc rgb "grey" fs noborder
set object 68 rect from 165.5,35.4 to 186.5,36.4 fc rgb "white"
set object 69 rect from 194.5,35.4 to 215.5,36.4 fc rgb "grey" fs noborder
set object 70 rect from 258.5,35.4 to 279.5,36.4 fc rgb "white"
set object 71 rect from 294.5,35.4 to 315.5,36.4 fc rgb "grey" fs noborder
set object 72 rect from 321.5,35.4 to 342.5,36.4 fc rgb "white"
set object 73 rect from 347.5,35.4 to 368.5,36.4 fc rgb "grey" fs noborder
set object 74 rect from 0.5,38.4 to 10.5,38.6 fc rgb "red" fs noborder
set object 75 rect from 91.5,38.4 to 98.5,38.6 fc rgb "red" fs noborder
set object 76 rect from 143.5,38.4 to 149.5,38.6 fc rgb "red" fs noborder
set object 77 rect from 182.5,38.4 to 192.5,38.6 fc rgb "red" fs noborder
set object 78 rect from 281.5,38.4 to 291.5,38.6 fc rgb "red" fs noborder
set object 79 rect from 340.5,38.4 to 348.5,38.6 fc rgb "red" fs noborder
set object 80 rect from 33.5,39.2 to 70.5,39.4 fc rgb "blue" fs noborder
set object 81 rect from 119.5,39.2 to 122.5,39.4 fc rgb "blue" fs noborder
set object 82 rect from 165.5,39.2 to 166.5,39.4 fc rgb "blue" fs noborder
set object 83 rect from 218.5,39.2 to 259.5,39.4 fc rgb "blue" fs noborder
set object 84 rect from 313.5,39.2 to 319.5,39.4 fc rgb "blue" fs noborder
set object 85 rect from 368.5,39.2 to 486.5,39.4 fc rgb "blue" fs noborder
set object 86 rect from 10.5,38.4 to 33.5,39.4 fc rgb "grey" fs noborder
set object 87 rect from 70.5,38.4 to 91.5,39.4 fc rgb "white"
set object 88 rect from 98.5,38.4 to 119.5,39.4 fc rgb "grey" fs noborder
set object 89 rect from 122.5,38.4 to 143.5,39.4 fc rgb "white"
set object 90 rect from 149.5,38.4 to 165.5,39.4 fc rgb "grey" fs noborder
set object 91 rect from 166.5,38.4 to 182.5,39.4 fc rgb "white"
set object 92 rect from 192.5,38.4 to 218.5,39.4 fc rgb "grey" fs noborder
set object 93 rect from 259.5,38.4 to 281.5,39.4 fc rgb "white"
set object 94 rect from 291.5,38.4 to 313.5,39.4 fc rgb "grey" fs noborder
set object 95 rect from 319.5,38.4 to 340.5,39.4 fc rgb "white"
set object 96 rect from 348.5,38.4 to 368.5,39.4 fc rgb "grey" fs noborder
set object 97 rect from 10.5,38.4 to 33.5,39.4 fc rgb "grey" fs noborder
set object 98 rect from 70.5,38.4 to 91.5,39.4 fc rgb "white"
set object 99 rect from 98.5,38.4 to 119.5,39.4 fc rgb "grey" fs noborder
set object 100 rect from 122.5,38.4 to 143.5,39.4 fc rgb "white"
set object 101 rect from 149.5,38.4 to 165.5,39.4 fc rgb "grey" fs noborder
set object 102 rect from 166.5,38.4 to 182.5,39.4 fc rgb "white"
set object 103 rect from 192.5,38.4 to 218.5,39.4 fc rgb "grey" fs noborder
set object 104 rect from 259.5,38.4 to 281.5,39.4 fc rgb "white"
set object 105 rect from 291.5,38.4 to 313.5,39.4 fc rgb "grey" fs noborder
set object 106 rect from 319.5,38.4 to 340.5,39.4 fc rgb "white"
set object 107 rect from 348.5,38.4 to 368.5,39.4 fc rgb "grey" fs noborder
set object 108 rect from 0.5,41.4 to 9.5,41.6 fc rgb "red" fs noborder
set object 109 rect from 89.5,41.4 to 97.5,41.6 fc rgb "red" fs noborder
set object 110 rect from 143.5,41.4 to 154.5,41.6 fc rgb "red" fs noborder
set object 111 rect from 214.5,41.4 to 232.5,41.6 fc rgb "red" fs noborder
set object 112 rect from 283.5,41.4 to 292.5,41.6 fc rgb "red" fs noborder
set object 113 rect from 342.5,41.4 to 350.5,41.6 fc rgb "red" fs noborder
set object 114 rect from 29.5,42.2 to 66.5,42.4 fc rgb "blue" fs noborder
set object 115 rect from 116.5,42.2 to 122.5,42.4 fc rgb "blue" fs noborder
set object 116 rect from 180.5,42.2 to 195.5,42.4 fc rgb "blue" fs noborder
set object 117 rect from 252.5,42.2 to 260.5,42.4 fc rgb "blue" fs noborder
set object 118 rect from 314.5,42.2 to 319.5,42.4 fc rgb "blue" fs noborder
set object 119 rect from 371.5,42.2 to 486.5,42.4 fc rgb "blue" fs noborder
set object 120 rect from 9.5,41.4 to 29.5,42.4 fc rgb "grey" fs noborder
set object 121 rect from 66.5,41.4 to 89.5,42.4 fc rgb "white"
set object 122 rect from 97.5,41.4 to 116.5,42.4 fc rgb "grey" fs noborder
set object 123 rect from 122.5,41.4 to 143.5,42.4 fc rgb "white"
set object 124 rect from 154.5,41.4 to 180.5,42.4 fc rgb "grey" fs noborder
set object 125 rect from 195.5,41.4 to 214.5,42.4 fc rgb "white"
set object 126 rect from 232.5,41.4 to 252.5,42.4 fc rgb "grey" fs noborder
set object 127 rect from 260.5,41.4 to 283.5,42.4 fc rgb "white"
set object 128 rect from 292.5,41.4 to 314.5,42.4 fc rgb "grey" fs noborder
set object 129 rect from 319.5,41.4 to 342.5,42.4 fc rgb "white"
set object 130 rect from 350.5,41.4 to 371.5,42.4 fc rgb "grey" fs noborder
set object 131 rect from 9.5,41.4 to 29.5,42.4 fc rgb "grey" fs noborder
set object 132 rect from 66.5,41.4 to 89.5,42.4 fc rgb "white"
set object 133 rect from 97.5,41.4 to 116.5,42.4 fc rgb "grey" fs noborder
set object 134 rect from 122.5,41.4 to 143.5,42.4 fc rgb "white"
set object 135 rect from 154.5,41.4 to 180.5,42.4 fc rgb "grey" fs noborder
set object 136 rect from 195.5,41.4 to 214.5,42.4 fc rgb "white"
set object 137 rect from 232.5,41.4 to 252.5,42.4 fc rgb "grey" fs noborder
set object 138 rect from 260.5,41.4 to 283.5,42.4 fc rgb "white"
set object 139 rect from 292.5,41.4 to 314.5,42.4 fc rgb "grey" fs noborder
set object 140 rect from 319.5,41.4 to 342.5,42.4 fc rgb "white"
set object 141 rect from 350.5,41.4 to 371.5,42.4 fc rgb "grey" fs noborder
set object 142 rect from 0.5,44.4 to 9.5,44.6 fc rgb "red" fs noborder
set object 143 rect from 91.5,44.4 to 93.5,44.6 fc rgb "red" fs noborder
set object 144 rect from 142.5,44.4 to 149.5,44.6 fc rgb "red" fs noborder
set object 145 rect from 180.5,44.4 to 193.5,44.6 fc rgb "red" fs noborder
set object 146 rect from 279.5,44.4 to 291.5,44.6 fc rgb "red" fs noborder
set object 147 rect from 340.5,44.4 to 347.5,44.6 fc rgb "red" fs noborder
set object 148 rect from 30.5,45.2 to 70.5,45.4 fc rgb "blue" fs noborder
set object 149 rect from 114.5,45.2 to 121.5,45.4 fc rgb "blue" fs noborder
set object 150 rect from 164.5,45.2 to 165.5,45.4 fc rgb "blue" fs noborder
set object 151 rect from 214.5,45.2 to 258.5,45.4 fc rgb "blue" fs noborder
set object 152 rect from 312.5,45.2 to 319.5,45.4 fc rgb "blue" fs noborder
set object 153 rect from 368.5,45.2 to 486.5,45.4 fc rgb "blue" fs noborder
set object 154 rect from 9.5,44.4 to 30.5,45.4 fc rgb "grey" fs noborder
set object 155 rect from 70.5,44.4 to 91.5,45.4 fc rgb "white"
set object 156 rect from 93.5,44.4 to 114.5,45.4 fc rgb "grey" fs noborder
set object 157 rect from 121.5,44.4 to 142.5,45.4 fc rgb "white"
set object 158 rect from 149.5,44.4 to 164.5,45.4 fc rgb "grey" fs noborder
set object 159 rect from 165.5,44.4 to 180.5,45.4 fc rgb "white"
set object 160 rect from 193.5,44.4 to 214.5,45.4 fc rgb "grey" fs noborder
set object 161 rect from 258.5,44.4 to 279.5,45.4 fc rgb "white"
set object 162 rect from 291.5,44.4 to 312.5,45.4 fc rgb "grey" fs noborder
set object 163 rect from 319.5,44.4 to 340.5,45.4 fc rgb "white"
set object 164 rect from 347.5,44.4 to 368.5,45.4 fc rgb "grey" fs noborder
set object 165 rect from 9.5,44.4 to 30.5,45.4 fc rgb "grey" fs noborder
set object 166 rect from 70.5,44.4 to 91.5,45.4 fc rgb "white"
set object 167 rect from 93.5,44.4 to 114.5,45.4 fc rgb "grey" fs noborder
set object 168 rect from 121.5,44.4 to 142.5,45.4 fc rgb "white"
set object 169 rect from 149.5,44.4 to 164.5,45.4 fc rgb "grey" fs noborder
set object 170 rect from 165.5,44.4 to 180.5,45.4 fc rgb "white"
set object 171 rect from 193.5,44.4 to 214.5,45.4 fc rgb "grey" fs noborder
set object 172 rect from 258.5,44.4 to 279.5,45.4 fc rgb "white"
set object 173 rect from 291.5,44.4 to 312.5,45.4 fc rgb "grey" fs noborder
set object 174 rect from 319.5,44.4 to 340.5,45.4 fc rgb "white"
set object 175 rect from 347.5,44.4 to 368.5,45.4 fc rgb "grey" fs noborder
set object 176 rect from 0.5,47.4 to 9.5,47.6 fc rgb "red" fs noborder
set object 177 rect from 91.5,47.4 to 95.5,47.6 fc rgb "red" fs noborder
set object 178 rect from 142.5,47.4 to 143.5,47.6 fc rgb "red" fs noborder
set object 179 rect from 186.5,47.4 to 193.5,47.6 fc rgb "red" fs noborder
set object 180 rect from 279.5,47.4 to 291.5,47.6 fc rgb "red" fs noborder
set object 181 rect from 340.5,47.4 to 347.5,47.6 fc rgb "red" fs noborder
set object 182 rect from 30.5,48.2 to 70.5,48.4 fc rgb "blue" fs noborder
set object 183 rect from 116.5,48.2 to 121.5,48.4 fc rgb "blue" fs noborder
set object 184 rect from 164.5,48.2 to 165.5,48.4 fc rgb "blue" fs noborder
set object 185 rect from 214.5,48.2 to 258.5,48.4 fc rgb "blue" fs noborder
set object 186 rect from 312.5,48.2 to 319.5,48.4 fc rgb "blue" fs noborder
set object 187 rect from 368.5,48.2 to 486.5,48.4 fc rgb "blue" fs noborder
set object 188 rect from 9.5,47.4 to 30.5,48.4 fc rgb "grey" fs noborder
set object 189 rect from 70.5,47.4 to 91.5,48.4 fc rgb "white"
set object 190 rect from 95.5,47.4 to 116.5,48.4 fc rgb "grey" fs noborder
set object 191 rect from 121.5,47.4 to 142.5,48.4 fc rgb "white"
set object 192 rect from 143.5,47.4 to 164.5,48.4 fc rgb "grey" fs noborder
set object 193 rect from 165.5,47.4 to 186.5,48.4 fc rgb "white"
set object 194 rect from 193.5,47.4 to 214.5,48.4 fc rgb "grey" fs noborder
set object 195 rect from 258.5,47.4 to 279.5,48.4 fc rgb "white"
set object 196 rect from 291.5,47.4 to 312.5,48.4 fc rgb "grey" fs noborder
set object 197 rect from 319.5,47.4 to 340.5,48.4 fc rgb "white"
set object 198 rect from 347.5,47.4 to 368.5,48.4 fc rgb "grey" fs noborder
set object 199 rect from 9.5,47.4 to 30.5,48.4 fc rgb "grey" fs noborder
set object 200 rect from 70.5,47.4 to 91.5,48.4 fc rgb "white"
set object 201 rect from 95.5,47.4 to 116.5,48.4 fc rgb "grey" fs noborder
set object 202 rect from 121.5,47.4 to 142.5,48.4 fc rgb "white"
set object 203 rect from 143.5,47.4 to 164.5,48.4 fc rgb "grey" fs noborder
set object 204 rect from 165.5,47.4 to 186.5,48.4 fc rgb "white"
set object 205 rect from 193.5,47.4 to 214.5,48.4 fc rgb "grey" fs noborder
set object 206 rect from 258.5,47.4 to 279.5,48.4 fc rgb "white"
set object 207 rect from 291.5,47.4 to 312.5,48.4 fc rgb "grey" fs noborder
set object 208 rect from 319.5,47.4 to 340.5,48.4 fc rgb "white"
set object 209 rect from 347.5,47.4 to 368.5,48.4 fc rgb "grey" fs noborder
plot '/static/tmp/tmp_lgKEPk/rst_eI5I8V/seq_0///DG1.txt' axes x1y2 w l t '' lt 3 lw 4
exit
