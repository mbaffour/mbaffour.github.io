set encoding iso_8859_1
set xrange [1:47]
set yrange [0.83:0.95]
set autoscale xfix
set ter png enh interlace size 2400,840 font 'Nimbus,40'
set xlabel 'Position'
set ylabel 'Reliability           ' 
set ytics nomirror 0.5,0.1,0.8
set out '/static/tmp/tmp_uTiKqf/rst__Lydbu/seq_0///Topcons/topcons.large.png'
set tmargin 1.3
set lmargin 11.5
set rmargin 6.5
set label 'TOPCONS' font 'Nimbus,42' at screen 0.022,0.775
set object 1 rect from 43.5,0.86 to 47.5,0.864875 fc rgb "red" fs noborder
set object 2 rect from 0.5,0.881375 to 22.5,0.88625 fc rgb "blue" fs noborder
set object 3 rect from 22.5,0.86 to 43.5,0.88625 fc rgb "white"
set object 4 rect from 22.5,0.86 to 43.5,0.88625 fc rgb "white"
plot '/static/tmp/tmp_uTiKqf/rst__Lydbu/seq_0///Topcons/reliability.final' w l t '' lc rgb "black" lw 4
exit
