set encoding iso_8859_1
set xrange [1:90]
set yrange [0.83:1]
set autoscale xfix
set ter png enh interlace size 2400,840 font 'Nimbus,40'
set xlabel 'Position'
set ylabel 'Reliability           ' 
set ytics nomirror 0.4,0.1,0.8
set out '/static/tmp/tmp_6cAK_Q/rst_oKhCG9/seq_0///Topcons/topcons.large.png'
set tmargin 1.3
set lmargin 11.5
set rmargin 6.5
set label 'TOPCONS' font 'Nimbus,42' at screen 0.022,0.775
set object 1 rect from 0.5,0.88 to 1.5,0.8865 fc rgb "red" fs noborder
set object 2 rect from 57.5,0.88 to 59.5,0.8865 fc rgb "red" fs noborder
set object 3 rect from 22.5,0.9085 to 36.5,0.915 fc rgb "blue" fs noborder
set object 4 rect from 80.5,0.9085 to 90.5,0.915 fc rgb "blue" fs noborder
set object 5 rect from 1.5,0.88 to 22.5,0.915 fc rgb "grey" fs noborder
set object 6 rect from 36.5,0.88 to 57.5,0.915 fc rgb "white"
set object 7 rect from 59.5,0.88 to 80.5,0.915 fc rgb "grey" fs noborder
set object 8 rect from 1.5,0.88 to 22.5,0.915 fc rgb "grey" fs noborder
set object 9 rect from 36.5,0.88 to 57.5,0.915 fc rgb "white"
set object 10 rect from 59.5,0.88 to 80.5,0.915 fc rgb "grey" fs noborder
plot '/static/tmp/tmp_6cAK_Q/rst_oKhCG9/seq_0///Topcons/reliability.final' w l t '' lc rgb "black" lw 4
exit
