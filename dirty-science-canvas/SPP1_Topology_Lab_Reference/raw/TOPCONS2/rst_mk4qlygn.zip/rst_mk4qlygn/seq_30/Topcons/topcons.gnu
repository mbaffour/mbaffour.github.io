set encoding iso_8859_1
set xrange [1:184]
set yrange [0.83:1.15]
set autoscale xfix
set ter png enh interlace size 2400,840 font 'Nimbus,40'
set xlabel 'Position'
set ylabel 'Reliability           ' 
set ytics nomirror 0.4,0.1,0.9
set out '/static/tmp/tmp_7yo07g/rst_csd4GH/seq_0///Topcons/topcons.large.png'
set tmargin 1.3
set lmargin 11.5
set rmargin 6.5
set label 'TOPCONS' font 'Nimbus,42' at screen 0.022,0.775
set object 1 rect from 173.5,1 to 184.5,1.008125 fc rgb "red" fs noborder
set object 2 rect from 0.5,1.035625 to 152.5,1.04375 fc rgb "blue" fs noborder
set object 3 rect from 152.5,1 to 173.5,1.04375 fc rgb "white"
set object 4 rect from 152.5,1 to 173.5,1.04375 fc rgb "white"
plot '/static/tmp/tmp_7yo07g/rst_csd4GH/seq_0///Topcons/reliability.final' w l t '' lc rgb "black" lw 4
exit
