set encoding iso_8859_1
set xrange [1:1032]
set yrange [0.83:1.35]
set autoscale xfix
set ter png enh interlace size 2400,840 font 'Nimbus,40'
set xlabel 'Position'
set ylabel 'Reliability           ' 
set ytics nomirror 0.3,0.1,1
set out '/static/tmp/tmp_pVKhYF/rst_2z0pm6/seq_0///Topcons/topcons.large.png'
set tmargin 1.3
set lmargin 11.5
set rmargin 6.5
set label 'TOPCONS' font 'Nimbus,42' at screen 0.022,0.775
set object 1 rect from 0.5,1.14 to 70.5,1.151375 fc rgb "red" fs noborder
set object 2 rect from 129.5,1.14 to 395.5,1.151375 fc rgb "red" fs noborder
set object 3 rect from 455.5,1.14 to 562.5,1.151375 fc rgb "red" fs noborder
set object 4 rect from 669.5,1.14 to 1032.5,1.151375 fc rgb "red" fs noborder
set object 5 rect from 91.5,1.189875 to 108.5,1.20125 fc rgb "blue" fs noborder
set object 6 rect from 416.5,1.189875 to 434.5,1.20125 fc rgb "blue" fs noborder
set object 7 rect from 583.5,1.189875 to 648.5,1.20125 fc rgb "blue" fs noborder
set object 8 rect from 70.5,1.14 to 91.5,1.20125 fc rgb "grey" fs noborder
set object 9 rect from 108.5,1.14 to 129.5,1.20125 fc rgb "white"
set object 10 rect from 395.5,1.14 to 416.5,1.20125 fc rgb "grey" fs noborder
set object 11 rect from 434.5,1.14 to 455.5,1.20125 fc rgb "white"
set object 12 rect from 562.5,1.14 to 583.5,1.20125 fc rgb "grey" fs noborder
set object 13 rect from 648.5,1.14 to 669.5,1.20125 fc rgb "white"
set object 14 rect from 70.5,1.14 to 91.5,1.20125 fc rgb "grey" fs noborder
set object 15 rect from 108.5,1.14 to 129.5,1.20125 fc rgb "white"
set object 16 rect from 395.5,1.14 to 416.5,1.20125 fc rgb "grey" fs noborder
set object 17 rect from 434.5,1.14 to 455.5,1.20125 fc rgb "white"
set object 18 rect from 562.5,1.14 to 583.5,1.20125 fc rgb "grey" fs noborder
set object 19 rect from 648.5,1.14 to 669.5,1.20125 fc rgb "white"
plot '/static/tmp/tmp_pVKhYF/rst_2z0pm6/seq_0///Topcons/reliability.final' w l t '' lc rgb "black" lw 4
exit
