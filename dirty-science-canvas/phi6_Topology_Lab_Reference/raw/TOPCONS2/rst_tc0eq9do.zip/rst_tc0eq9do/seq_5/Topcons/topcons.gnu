set encoding iso_8859_1
set xrange [1:168]
set yrange [0.83:1.35]
set autoscale xfix
set ter png enh interlace size 2400,840 font 'Nimbus,40'
set xlabel 'Position'
set ylabel 'Reliability           ' 
set ytics nomirror 0.3,0.1,1
set out '/static/tmp/tmp_m5nznzab/rst_zo0fck96/seq_0///Topcons/topcons.large.png'
set tmargin 1.3
set lmargin 11.5
set rmargin 6.5
set label 'TOPCONS' font 'Nimbus,42' at screen 0.022,0.775
set object 1 rect from 0.5,1.14 to 27.5,1.151375 fc rgb "red" fs noborder
set object 2 rect from 70.5,1.14 to 90.5,1.151375 fc rgb "red" fs noborder
set object 3 rect from 164.5,1.14 to 168.5,1.151375 fc rgb "red" fs noborder
set object 4 rect from 48.5,1.189875 to 49.5,1.20125 fc rgb "blue" fs noborder
set object 5 rect from 111.5,1.189875 to 143.5,1.20125 fc rgb "blue" fs noborder
set object 6 rect from 27.5,1.14 to 48.5,1.20125 fc rgb "grey" fs noborder
set object 7 rect from 49.5,1.14 to 70.5,1.20125 fc rgb "white"
set object 8 rect from 90.5,1.14 to 111.5,1.20125 fc rgb "grey" fs noborder
set object 9 rect from 143.5,1.14 to 164.5,1.20125 fc rgb "white"
set object 10 rect from 27.5,1.14 to 48.5,1.20125 fc rgb "grey" fs noborder
set object 11 rect from 49.5,1.14 to 70.5,1.20125 fc rgb "white"
set object 12 rect from 90.5,1.14 to 111.5,1.20125 fc rgb "grey" fs noborder
set object 13 rect from 143.5,1.14 to 164.5,1.20125 fc rgb "white"
plot '/static/tmp/tmp_m5nznzab/rst_zo0fck96/seq_0///Topcons/reliability.final' w l t '' lc rgb "black" lw 4
exit
